class test
{
	boolean ab();
	boolean abc);
}
