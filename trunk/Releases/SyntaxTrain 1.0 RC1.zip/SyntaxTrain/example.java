class test
{
	boolean ab();
	boolean abc()
{
	throw new ggff()
}
}
