What is SyntaxTrain:

SyntaxTrain is a tool, which reads source files, finds syntax errors and visually displays them, based upon a given grammar file, created using the BNF-Compiler. SyntaxTrain also helps the user understanding what options he/she has at the given error, so the error is fixed and understood without using several hours.

--SyntaxTrain--

In order to use SyntaxTrain you first have to make a grammar file using the BNF-Compiler or you can use the pre-compiled java grammar file called javagrammar.jar.
The file must be referenced in the options.xml file under GUI, Path, grammarFile (by default the javagrammar is used).

To start SyntaxTrain, simply double-click syntaxTrain.jar.

--BNF-Compiler--

The Bnf compiler is a tool that takes a BNF which specifies a language and makes it into a grammar file, which can be used by SyntaxTrain.
For an example, see javagrammar.bnf.
The Compiler expects the first rule to be the starting rule.
The BNF must not be left recursive and has to be decidable.
Left recursive means that a rule cannot refer to itself as the first argument, ex. "myRule = myRule ..".
Decidable means that there must not be two ways to match the same string.
The following rules have been pre-programmed into the grammar file and can be used:
- IDENTIFIER (any string only consisting of letters, underscore and numbers and starting with a letter or underscore).
- INT (matches integer values).
- FLOAT (matches float values, ex. 1.2, .5 or 3e-3).
- HEX (matches hex values, ex. ff or 1b).
- STRING (matches escape sequence inside two quotes).
- HEX_DIGIT (single hex value).
Additionally the following are automatically ignored (without needing any reference).
- comment (rest of sentence after '//' and everything between /* and */).
- Whitespace (new lines, line feed, tabs and spaces).

To run the Bnf-Compiler type the following in a console "java -jar BnfCompiler.jar bnfFilename", where bnfFilename is the name of your file containing the bnf, ex. javagrammar.jar.
